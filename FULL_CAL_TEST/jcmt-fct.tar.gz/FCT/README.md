# CoBr8/NRC_pub/FULL_CAL_TEST/FCT/

Contained in this folder:
* Regional tables
* png's comparing Steve's compact source calibration vs Colton's autocorrelation calibration
* FCT.sh, a bash script which generates each region's table using NEW_full_cal_test.py
